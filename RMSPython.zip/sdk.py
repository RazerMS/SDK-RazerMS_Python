# core imports 
import logging, hashlib
import requests as HttpClient
from io import BytesIO

# optional, depending on your application framework
from flask import Flask
from flask import render_template, flash, request

# configure verbose logging for HTTP requests
try: # for Python 3
    from http.client import HTTPConnection
except ImportError:
    from httplib import HTTPConnection
HTTPConnection.debuglevel = 1

logging.basicConfig()
logging.getLogger().setLevel(logging.DEBUG)
handler = logging.FileHandler('/app/sdk.log')
requests_log = logging.getLogger("urllib3")
requests_log.setLevel(logging.DEBUG)
requests_log.addHandler(handler)
requests_log.propagate = True
# end configuration

merchant_id = ''                              #Insert merchant id here
verify_key = ''         #Insert Verify Key here
private_verify_key = '' #Insert Private vKey here
enviroment = "sandbox"

if merchant_id in (None, '') or verify_key in (None, ''):
  raise "`merchant_id` and `vkey` cannot be empty!"

if (enviroment == "sandbox"):
  url = "https://sandbox.merchant.razer.com/RMS/API/chkstat/returnipn.php" #return ipn url
  payment_request = "https://sandbox.merchant.razer.com/RMS/pay/" + merchant_id + "/" #payment request url
elif (enviroment == "production"):
  url = "https://www.onlinepayment.com.my/MOLPay/API/chkstat/returnipn.php" #return ipn url
  payment_request = "https://www.onlinepayment.com.my/MOLPay/pay/" + merchant_id + "/" #payment request url

#App config
app = Flask(__name__)
app.config['DEBUG'] = False

#Encrypt string with MD5
def computeMD5hash(my_string):
  m = hashlib.md5()
  m.update(my_string.encode('utf-8'))
  return m.hexdigest()

def IPN(postdata):
  res = HttpClient.post(
    url, 
    data = postdata
  )

@app.route("/returnurl", methods=['POST'])
def returnurl():
  tranID   = request.form['tranID']
  orderid  = request.form['orderid']
  status   = request.form['status']
  domain   = request.form['domain']
  amount   = request.form['amount']
  currency = request.form['currency']
  appcode  = request.form['appcode']
  paydate  = request.form['paydate']
  skey     = request.form['skey']

  key_0    = f"{tranID}{orderid}{status}{domain}{amount}{currency}"
  key0     = computeMD5hash(key_0)
  key_1    = f"{paydate}{domain}{key0}{appcode}{private_verify_key}"
  key1     = computeMD5hash(key_1)

  if (skey != key1):
    status = "-1" #Invalid transaction.
    #Merchant might issue a requery to MOLPay to double check payment status with MOLPay.

  #if (status == "00"):
    #write your script here .....
  #else:
    #failure action. Write your script here .....
    #Merchant might send query to MOLPay using Merchant requery
    #to double check payment status for that particular order.

  treq = "1"
  postdata = {
    "treq": treq,
    "tranID": tranID,
    "orderid": orderid,
    "status": status,
    "domain": domain,
    "amount": amount,
    "currency": currency,
    "appcode": appcode,
    "paydate": paydate,
    "skey": skey
  }

  nbcb = request.form.get('nbcb')
  if (nbcb == "1"): #Callback URL
    return "CBTOKEN:MPSTATOK"
    
  if (nbcb == "2"): #Notification URL
    postdata["nbcb"] = nbcb
    IPN(postdata)
    return
  
  IPN(postdata)
  return "<p>Success return!</p>"

amount = '1.20' #Insert amount here
orderid = '601' #Insert order id here
v_code = f"{amount}{merchant_id}{orderid}{verify_key}"
vcode = computeMD5hash(v_code)

@app.route("/", methods=['GET'])
def read():
  return render_template('merchant.html', amount = amount, orderid = orderid, vcode = vcode, payment_request = payment_request)

if __name__ == "__main__":
  app.run(
    host="0.0.0.0",
    port=5000
  )