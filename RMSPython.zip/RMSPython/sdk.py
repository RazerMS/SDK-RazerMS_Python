from flask import Flask, render_template, flash, request
import hashlib
import pycurl
from io import BytesIO

merchant_id = '' #Insert merchant id here
vkey = '' #Insert Verify Key here
enviroment = "sandbox"

if (enviroment == "sandbox"):
    url = "https://sandbox.merchant.razer.com/RMS/API/chkstat/returnipn.php" #return ipn url
    payment_request = "https://sandbox.merchant.razer.com/RMS/pay/" + merchant_id + "/" #payment request url
elif (enviroment == "production"):
    url = "https://www.onlinepayment.com.my/MOLPay/API/chkstat/returnipn.php" #return ipn url
    payment_request = "https://www.onlinepayment.com.my/MOLPay/pay/" + merchant_id + "/" #payment request url

#App config
app = Flask(__name__)
app.config['DEBUG'] = False

#Encrypt string with MD5
def computeMD5hash(my_string):
    m = hashlib.md5()
    m.update(my_string.encode('utf-8'))
    return m.hexdigest()

@app.route("/returnurl", methods=['POST'])
def returnurl():
    tranID=request.form['tranID']
    orderid=request.form['orderid']
    status=request.form['status']
    domain=request.form['domain']
    amount=request.form['amount']
    currency=request.form['currency']
    appcode=request.form['appcode']
    paydate=request.form['paydate']
    skey=request.form['skey']
    vkey = '' #Insert Private vKey here

    key_0=tranID+orderid+status+domain+amount+currency
    key0 = computeMD5hash(key_0)
    key_1=paydate+domain+key0+appcode+vkey
    key1 = computeMD5hash(key_1)

    if (skey != key1):
        status = "-1" #Invalid transaction.
        #Merchant might issue a requery to MOLPay to double check payment status with MOLPay.

    #if (status == "00"):
        #write your script here .....
    #else:
        #failure action. Write your script here .....
        #Merchant might send query to MOLPay using Merchant requery
        #to double check payment status for that particular order.

    treq = "1"
    postdata = "treq="+treq+"&tranID="+tranID+"&orderid="+orderid+"&status="+status+"&domain="+domain+"&amount="+amount+"&currency="+currency+"&appcode="+appcode+"&paydate="+paydate+"&skey="+skey
    
    #CURLINFO_HEADER_OUT equivalent
    sent_headers = []
    received_headers = []
    def collect_headers(debug_type, debug_msg):
        if debug_type == pycurl.INFOTYPE_HEADER_OUT:
                sent_headers.append(debug_msg)
        if debug_type == pycurl.INFOTYPE_HEADER_IN:
                received_headers.append(debug_msg)

    buffer = BytesIO()
    def IPN():
        ch = pycurl.Curl()
        ch.setopt(ch.POST, 1)
        ch.setopt(ch.POSTFIELDS, postdata)
        ch.setopt(ch.URL, url)
        ch.setopt(ch.HEADER, 1)
        ch.setopt(ch.DEBUGFUNCTION, collect_headers) #CURLINFO_HEADER_OUT equivalent
        ch.setopt(ch.WRITEDATA, buffer) #CURLOPT_RETURNTRANSFER equivalent
        ch.setopt(ch.SSL_VERIFYPEER, False)
        ch.setopt(ch.SSLVERSION, 6)
        ch.perform()
        ch.close()

    nbcb=request.form.get('nbcb')
    if (nbcb == "1"): #Callback URL
        print ("CBTOKEN:MPSTATOK")
    elif (nbcb == "2"): #Notification URL
        postdata += "&nbcb="+nbcb
        IPN()
    else: #Return URL
        IPN()

    return "<p>Success return!</p>"

amount = '61.01' #Insert amount here
orderid = '601' #Insert order id here
v_code = amount+merchant_id+orderid+vkey
vcode = computeMD5hash(v_code)

@app.route("/", methods=['GET'])
def read():
    return render_template('merchant.html', amount = amount, orderid = orderid, vcode = vcode, payment_request = payment_request)

if __name__ == "__main__":
    app.run()